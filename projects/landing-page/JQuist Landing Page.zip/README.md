# Landing Page Project

## Table of Contents

* [Instructions](#instructions)

## Instructions

Hi! I'm not sure exactly what's supposed to be in here, but here's a breakdown of what I've done in the project:

I used Javascript to create a navigation menu that will adjust automatically if new sections are added.
The navigation menu scrolls to the indicated section smoothly, without the use of a hyperlink.
Scrolling through the page adds and removes an active class to the section on screen to emphasize it. The class is removed when the page scrolls away.
I also added a button to return to the top of the page that appears after scrolling part of the way down the screen.
